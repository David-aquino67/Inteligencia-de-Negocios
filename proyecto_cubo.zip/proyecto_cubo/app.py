from flask import Flask, render_template, request
import pandas as pd 
from funciones.generarDatos import generar_dataset
from funciones.crearCubo import cubo_base
from funciones.operacionesCubo import slice_por_anio, dice_subset

app = Flask(__name__)

print("Generando dataset y cubo base...")
df_crudo = generar_dataset()
cubo = cubo_base(df_crudo)
print("¡Servidor listo!")


@app.route('/')
def index():
    """Página principal que muestra todas las visualizaciones."""
    
    
    cara_2024 = slice_por_anio(df_crudo, 2024)
   
    cara_html = pd.pivot_table(  
        cara_2024, 
        values="Ventas", 
        index="Producto", 
        columns="Región", 
        aggfunc="sum",
        margins=True
    ).to_html(classes='table table-striped table-hover', border=0)

    seccion_subset = dice_subset(
        df_crudo,
        anios=[2024, 2025],
        regiones=["Norte", "Sur"]
    )
    seccion_html = seccion_subset.head(20).to_html(classes='table table-striped table-hover', border=0, index=False)

    cubo_html = cubo.to_html(classes='table table-striped table-hover', border=0)
    
    return render_template(
        'index.html',
        cubo_completo=cubo_html,
        cara_cubo=cara_html,
        seccion_cubo=seccion_html
    )


@app.route('/celda')
def ver_celda():
    """
    d) Muestra los datos que soportan a una celda específica (Drill-through).
    Recibe los parámetros desde un formulario en index.html.
    """
    
    try:
        producto = request.args.get('producto')
        region = request.args.get('region')
        anio = int(request.args.get('anio'))
        trimestre = int(request.args.get('trimestre'))

        # Filtramos el DataFrame ORIGINAL (df_crudo)
        filtro = (
            (df_crudo['Producto'] == producto) &
            (df_crudo['Región'] == region) &
            (df_crudo['Año'] == anio) &
            (df_crudo['Trimestre'] == trimestre)
        )
        
        datos_celda = df_crudo[filtro]
        
        # Parámetros para mostrar en el título
        params_str = f"Producto={producto}, Región={region}, Año={anio}, Trimestre={trimestre}"
        
        # Si no hay datos, mostramos un mensaje
        if datos_celda.empty:
            datos_html = "<p>No se encontraron datos para esta celda.</p>"
        else:
            datos_html = datos_celda.to_html(classes='table table-striped table-hover', border=0, index=False)

        return render_template('celda.html',
                               datos_celda=datos_html,
                               params=params_str)

    except Exception as e:
        return f"Error al procesar la solicitud: {e}. Asegúrate de que todos los campos estén completos."


if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=5000)